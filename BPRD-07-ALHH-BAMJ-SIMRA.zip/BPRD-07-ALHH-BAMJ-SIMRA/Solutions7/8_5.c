void main(int x){

    (0==0 ? print 10 : print 20);

    switch(x){
        case 1:
            print 100;
        case 2:
            print 200;
        case 3:
            print 300;
    }
}